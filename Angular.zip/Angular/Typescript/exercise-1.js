function greet(person) {
    alert("Username:" + person);
    return "Welcome username :" + person;
}
var user = "Sayak";
greet(user);
document.getElementById("div1").innerHTML = greet(user);
