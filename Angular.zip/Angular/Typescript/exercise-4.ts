interface Person{
    firstName:string;
    lastName:string;
}

class User implements Person
{
    firstName:string;
    lastName:string;
    constructor(firstName : string, lastName:string)
    {
        this.firstName=firstName;
        this.lastName=lastName;
    }

    greet(person : User)
    {

    return "Welcome "+person.firstName+" "+person.lastName;
    }
}



//let user:Person = {firstName:"John",lastName:"David"};

let user:User = new User("Mark","Ruffalo");

document.getElementById("div1").innerHTML=user.greet(user);
