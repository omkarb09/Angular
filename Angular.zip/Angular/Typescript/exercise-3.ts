interface Person{
    firstName:string;
    lastName:string;
}

function greet(person : Person):string{

 return "Welcome "+person.firstName+" "+person.lastName;
}

let user:Person = {firstName:"John",lastName:"David"};
greet(user);

document.getElementById("div1").innerHTML=greet(user);
