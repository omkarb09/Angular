function greet(person) {
    return "Welcome " + person.firstName + " " + person.lastName;
}
var user = { firstName: "John", lastName: "David" };
greet(user);
document.getElementById("div1").innerHTML = greet(user);
