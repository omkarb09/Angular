var User = /** @class */ (function () {
    function User(firstName, lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
    }
    User.prototype.greet = function (person) {
        return "Welcome " + person.firstName + " " + person.lastName;
    };
    return User;
}());
//let user:Person = {firstName:"John",lastName:"David"};
var user = new User("Mark", "Ruffalo");
document.getElementById("div1").innerHTML = user.greet(user);
