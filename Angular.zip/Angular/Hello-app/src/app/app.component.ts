import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
 //template:`<h3>good day</h3>`,
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Hello-app';

  onButtonClicked()
  {
    this.title="Button clicked";
  }
}
