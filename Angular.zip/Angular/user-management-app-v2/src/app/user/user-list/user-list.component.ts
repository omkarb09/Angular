import { Component, OnInit } from '@angular/core';
import{User} from '../user';


@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css']
})
export class UserListComponent implements OnInit {

  users:User[]= new Array();
  constructor() {
    this.users[0]=new User(1001,"John","David","abc123@gmail.com"
    ,"founder of Farbucks", new Date("1985-06-09"),"John");

    this.users[1]=new User(1002,"Sam","Winchester","SW123@gmail.com"
    ,"founder of Farbucks", new Date("1985-09-05"),"Sam");

    this.users[2]=new User(1003,"Dean","Winchester","DW123@gmail.com"
    ,"founder of Farbucks", new Date("1985-07-09"),"Dean");

    this.users[3]=new User(1004,"Michael","Jackson","MJ123@gmail.com"
    ,"founder of Farbucks", new Date("1966-01-01"),"Michael");

    this.users[4]=new User(1005,"Owen","Wilson","OW123@gmail.com"
    ,"founder of Farbucks", new Date("1958-07-10"),"Owen");


   }

  ngOnInit() {
  }

}
