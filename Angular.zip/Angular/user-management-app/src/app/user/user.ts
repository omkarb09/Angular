
export class User {
    id: number;
    firstName:string;
    lastName:string;
    email: string;
    profession: string;
    dateOfBirth:Date;
    imageUrl:string

    constructor(id: number, firstName:string,lastName:string, email:string, profession:string,dateOfBirth:Date, imageUrl:string)
    {
        this.id=id;
        this.firstName=firstName;
        this.lastName=lastName;
        this.email=email;
        this.profession=profession;
        this.dateOfBirth=dateOfBirth;
        this.imageUrl=imageUrl;
    }

    public toString(): string
    {
        return "Full Name: "+this.firstName+" "+this.lastName+","+"Date of Birth"+this.dateOfBirth.getDate()
        +"/"+this.dateOfBirth.getMonth()+"/"+this.dateOfBirth.getFullYear()+", Profession:"+this.profession;
    }
}
